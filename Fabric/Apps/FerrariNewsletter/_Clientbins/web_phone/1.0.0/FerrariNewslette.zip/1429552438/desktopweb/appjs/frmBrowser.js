define("frmBrowser", function() {
    return function(controller) {
        function addWidgetsfrmBrowser() {
            this.setDefaultUnit(voltmx.flex.DP);
            var headerBrowser = new com.hcl.demo.ferrari.SimpleHeader({
                "height": "70dp",
                "id": "headerBrowser",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "lblIconLeft": {
                        "text": "n"
                    },
                    "lblRight": {
                        "text": "  "
                    },
                    "lblTitle": {
                        "text": "  "
                    },
                    "SimpleHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var browser = new voltmx.ui.Browser({
                "bottom": 0,
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "browser",
                "isVisible": true,
                "left": "0dp",
                "setAsContent": false,
                "top": "70dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            this.compInstData = {
                "headerBrowser": {
                    "iconLeft": "n",
                    "iconRight": "  ",
                    "title": "  ",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(headerBrowser, browser);
        };
        return [{
            "addWidgets": addWidgetsfrmBrowser,
            "enabledForIdleTimeout": false,
            "id": "frmBrowser",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmDarkGrey",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});