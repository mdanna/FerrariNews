define("userfrmBrowserController", {
    ANDROID_URL_PREFIX: "http://docs.google.com/gview?embedded=true&url=",
    onViewCreated() {
        this.view.init = () => {
            this.view.headerBrowser.onClickLeft = () => new voltmx.mvc.Navigation('frmNewsletter').navigate();
            this.view.browser.onPageStarted = () => voltmx.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, false, null);
            this.view.browser.onPageFinished = () => voltmx.application.dismissLoadingScreen();
        };
    },
    onNavigate(url) {
        this.view.browser.htmlString = "";
        if (url) {
            url = kony.os.deviceInfo().name === 'android' && url.includes('.pdf') ? this.ANDROID_URL_PREFIX + url.replace(/&/g, '%26') : url;
            this.view.browser.requestURLConfig = {
                URL: url,
                requestMethod: constants.BROWSER_REQUEST_METHOD_GET
            };
        }
    }
});
define("frmBrowserControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("frmBrowserController", ["userfrmBrowserController", "frmBrowserControllerActions"], function() {
    var controller = require("userfrmBrowserController");
    var controllerActions = ["frmBrowserControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
