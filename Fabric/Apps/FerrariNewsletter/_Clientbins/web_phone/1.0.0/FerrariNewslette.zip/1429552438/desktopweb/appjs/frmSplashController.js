define("userfrmSplashController", {
    onViewCreated() {
        this.view.postShow = () => {
            voltmx.timer.schedule("splash", () => {
                new voltmx.mvc.Navigation('frmLogin').navigate();
            }, 1, false);
        };
    }
});
define("frmSplashControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("frmSplashController", ["userfrmSplashController", "frmSplashControllerActions"], function() {
    var controller = require("userfrmSplashController");
    var controllerActions = ["frmSplashControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
