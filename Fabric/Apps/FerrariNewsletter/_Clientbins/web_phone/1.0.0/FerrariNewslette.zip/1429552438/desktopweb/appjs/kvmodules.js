define('applicationController',{
    appInit: function(params) {
        skinsInit();
        voltmx.mvc.registry.add("com.hcl.demo.ferrari.BigTeaser", "BigTeaser", "BigTeaserController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.ferrari",
            "classname": "BigTeaser",
            "name": "com.hcl.demo.ferrari.BigTeaser"
        });
        voltmx.mvc.registry.add("com.hcl.demo.ferrari.DigitalPillsTeaser", "DigitalPillsTeaser", "DigitalPillsTeaserController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.ferrari",
            "classname": "DigitalPillsTeaser",
            "name": "com.hcl.demo.ferrari.DigitalPillsTeaser"
        });
        voltmx.mvc.registry.add("com.hcl.demo.ferrari.HamburgerMenu", "HamburgerMenu", "HamburgerMenuController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.ferrari",
            "classname": "HamburgerMenu",
            "name": "com.hcl.demo.ferrari.HamburgerMenu"
        });
        voltmx.mvc.registry.add("com.hcl.demo.ferrari.NumbersTeaser", "NumbersTeaser", "NumbersTeaserController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.ferrari",
            "classname": "NumbersTeaser",
            "name": "com.hcl.demo.ferrari.NumbersTeaser"
        });
        voltmx.mvc.registry.add("com.hcl.demo.ferrari.SimpleHeader", "SimpleHeader", "SimpleHeaderController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.ferrari",
            "classname": "SimpleHeader",
            "name": "com.hcl.demo.ferrari.SimpleHeader"
        });
        voltmx.mvc.registry.add("com.hcl.demo.ferrari.SmallTeaser", "SmallTeaser", "SmallTeaserController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.ferrari",
            "classname": "SmallTeaser",
            "name": "com.hcl.demo.ferrari.SmallTeaser"
        });
        voltmx.mvc.registry.add("flxSampleRowTemplate", "flxSampleRowTemplate", "flxSampleRowTemplateController");
        voltmx.mvc.registry.add("flxSectionHeaderTemplate", "flxSectionHeaderTemplate", "flxSectionHeaderTemplateController");
        voltmx.mvc.registry.add("flxMenuItem", "flxMenuItem", "flxMenuItemController");
        voltmx.mvc.registry.add("frmBrowser", "frmBrowser", "frmBrowserController");
        voltmx.mvc.registry.add("frmLogin", "frmLogin", "frmLoginController");
        voltmx.mvc.registry.add("frmMain", "frmMain", "frmMainController");
        voltmx.mvc.registry.add("frmNewsletter", "frmNewsletter", "frmNewsletterController");
        voltmx.mvc.registry.add("frmSplash", "frmSplash", "frmSplashController");
        setAppBehaviors();
    },
    postAppInitCallBack: function(eventObj) {},
    appmenuseq: function() {
        new voltmx.mvc.Navigation("frmSplash").navigate();
    }
});

define("com/hcl/demo/ferrari/BigTeaser/userBigTeaserController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
            defineGetter(this, 'url', () => {
                return this._url;
            });
            defineSetter(this, 'url', value => {
                this._url = value;
            });
        }
    };
});
define("com/hcl/demo/ferrari/BigTeaser/BigTeaserControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/hcl/demo/ferrari/BigTeaser/BigTeaserController", ["com/hcl/demo/ferrari/BigTeaser/userBigTeaserController", "com/hcl/demo/ferrari/BigTeaser/BigTeaserControllerActions"], function() {
    var controller = require("com/hcl/demo/ferrari/BigTeaser/userBigTeaserController");
    var actions = require("com/hcl/demo/ferrari/BigTeaser/BigTeaserControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "image", function(val) {
            this.view.imgTeaser.src = val;
        });
        defineGetter(this, "image", function() {
            return this.view.imgTeaser.src;
        });
        defineSetter(this, "title", function(val) {
            this.view.lblTitle.text = val;
        });
        defineGetter(this, "title", function() {
            return this.view.lblTitle.text;
        });
        defineSetter(this, "text", function(val) {
            this.view.lblText.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.lblText.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_onClickTeaser_h35c0e4813134a28926658e25a6654eb = function() {
        if (this.onClickTeaser) {
            this.onClickTeaser.apply(this, arguments);
        }
    }
    return controller;
});

define('com/hcl/demo/ferrari/BigTeaser/BigTeaser',[],function() {
    return function(controller) {
        var BigTeaser = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "440dp",
            "id": "BigTeaser",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "20dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "323dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "BigTeaser"), extendConfig({}, controller.args[1], "BigTeaser"), extendConfig({}, controller.args[2], "BigTeaser"));
        BigTeaser.setDefaultUnit(voltmx.flex.DP);
        var flxGroup = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxGroup",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_onClickTeaser_h35c0e4813134a28926658e25a6654eb,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "flxGroup"), extendConfig({}, controller.args[1], "flxGroup"), extendConfig({}, controller.args[2], "flxGroup"));
        flxGroup.setDefaultUnit(voltmx.flex.DP);
        var imgTeaser = new voltmx.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgTeaser",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "imagenewsletter1.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgTeaser"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgTeaser"), extendConfig({}, controller.args[2], "imgTeaser"));
        var flxContent = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "bottom": "30dp",
            "clipBounds": true,
            "id": "flxContent",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "reverseLayoutDirection": true,
            "left": "30dp",
            "isModalContainer": false,
            "right": "30dp",
            "skin": "slFbox",
            "top": "30dp",
            "zIndex": 1
        }, controller.args[0], "flxContent"), extendConfig({}, controller.args[1], "flxContent"), extendConfig({}, controller.args[2], "flxContent"));
        flxContent.setDefaultUnit(voltmx.flex.DP);
        var flxReadMore = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "bottom": 0,
            "clipBounds": true,
            "height": "21dp",
            "id": "flxReadMore",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "width": voltmx.flex.USE_PREFFERED_SIZE
        }, controller.args[0], "flxReadMore"), extendConfig({}, controller.args[1], "flxReadMore"), extendConfig({}, controller.args[2], "flxReadMore"));
        flxReadMore.setDefaultUnit(voltmx.flex.DP);
        var lblReadMore = new voltmx.ui.Label(extendConfig({
            "bottom": "0dp",
            "height": "20dp",
            "id": "lblReadMore",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknRegularWhite80",
            "text": "Read More",
            "textStyle": {},
            "width": "93dp",
            "zIndex": 1
        }, controller.args[0], "lblReadMore"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblReadMore"), extendConfig({}, controller.args[2], "lblReadMore"));
        var flxUnderline = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "bottom": 0,
            "clipBounds": true,
            "height": "1dp",
            "id": "flxUnderline",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxWhite",
            "width": "93dp",
            "zIndex": 1
        }, controller.args[0], "flxUnderline"), extendConfig({}, controller.args[1], "flxUnderline"), extendConfig({}, controller.args[2], "flxUnderline"));
        flxUnderline.setDefaultUnit(voltmx.flex.DP);
        flxUnderline.add();
        flxReadMore.add(lblReadMore, flxUnderline);
        var lblText = new voltmx.ui.Label(extendConfig({
            "bottom": "5dp",
            "id": "lblText",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknMediumWhite200",
            "text": "Sample teaser text spanning on several lines",
            "textStyle": {},
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblText"), extendConfig({}, controller.args[2], "lblText"));
        var lblTitle = new voltmx.ui.Label(extendConfig({
            "bottom": "5dp",
            "height": "24dp",
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknRegularWhite80",
            "text": "AUTOMOTIVE",
            "textStyle": {},
            "width": "120dp",
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        flxContent.add(flxReadMore, lblText, lblTitle);
        flxGroup.add(imgTeaser, flxContent);
        BigTeaser.add(flxGroup);
        return BigTeaser;
    }
})
;
define('com/hcl/demo/ferrari/BigTeaser/BigTeaserConfig',[],function() {
    return {
        "properties": [{
            "name": "image",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "title",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "url",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onClickTeaser"]
    }
});

define("com/hcl/demo/ferrari/DigitalPillsTeaser/userDigitalPillsTeaserController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this.view.preShow = () => {
                if (!this.initDone) {
                    this.view.rtTitle.doLayout = () => {
                        this.view.flxText.height = `${390 - this.view.rtTitle.frame.height}dp`;
                    };
                    this.initDone = true;
                }
            };
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
            defineGetter(this, 'url', () => {
                return this._url;
            });
            defineSetter(this, 'url', value => {
                this._url = value;
            });
        }
    };
});
define("com/hcl/demo/ferrari/DigitalPillsTeaser/DigitalPillsTeaserControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/hcl/demo/ferrari/DigitalPillsTeaser/DigitalPillsTeaserController", ["com/hcl/demo/ferrari/DigitalPillsTeaser/userDigitalPillsTeaserController", "com/hcl/demo/ferrari/DigitalPillsTeaser/DigitalPillsTeaserControllerActions"], function() {
    var controller = require("com/hcl/demo/ferrari/DigitalPillsTeaser/userDigitalPillsTeaserController");
    var actions = require("com/hcl/demo/ferrari/DigitalPillsTeaser/DigitalPillsTeaserControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "title", function(val) {
            this.view.rtTitle.text = val;
        });
        defineGetter(this, "title", function() {
            return this.view.rtTitle.text;
        });
        defineSetter(this, "text", function(val) {
            this.view.rtText.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.rtText.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/ferrari/DigitalPillsTeaser/DigitalPillsTeaser',[],function() {
    return function(controller) {
        var DigitalPillsTeaser = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "440dp",
            "id": "DigitalPillsTeaser",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "20dp",
            "isModalContainer": false,
            "skin": "sknFlxGrey",
            "top": "0dp",
            "width": "323dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "DigitalPillsTeaser"), extendConfig({}, controller.args[1], "DigitalPillsTeaser"), extendConfig({}, controller.args[2], "DigitalPillsTeaser"));
        DigitalPillsTeaser.setDefaultUnit(voltmx.flex.DP);
        var flxContent = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "400dp",
            "id": "flxContent",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "20dp",
            "isModalContainer": false,
            "right": 20,
            "skin": "slFbox",
            "top": "20dp"
        }, controller.args[0], "flxContent"), extendConfig({}, controller.args[1], "flxContent"), extendConfig({}, controller.args[2], "flxContent"));
        flxContent.setDefaultUnit(voltmx.flex.DP);
        var rtTitle = new voltmx.ui.RichText(extendConfig({
            "id": "rtTitle",
            "isVisible": true,
            "left": "0dp",
            "linkSkin": "defRichTextLink",
            "skin": "CopydefRichTextNormal0g3f98bb0c15249",
            "text": "RichText",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "rtTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "rtTitle"), extendConfig({}, controller.args[2], "rtTitle"));
        var flxText = new voltmx.ui.FlexScrollContainer(extendConfig({
            "allowHorizontalBounce": false,
            "allowVerticalBounce": true,
            "bounces": false,
            "clipBounds": true,
            "enableScrolling": true,
            "height": "200dp",
            "horizontalScrollIndicator": true,
            "id": "flxText",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "pagingEnabled": false,
            "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
            "skin": "slFSbox",
            "top": "10dp",
            "verticalScrollIndicator": false,
            "width": "100%"
        }, controller.args[0], "flxText"), extendConfig({}, controller.args[1], "flxText"), extendConfig({}, controller.args[2], "flxText"));
        flxText.setDefaultUnit(voltmx.flex.DP);
        var rtText = new voltmx.ui.RichText(extendConfig({
            "id": "rtText",
            "isVisible": true,
            "left": "0dp",
            "linkSkin": "rtBoldItalicWhite80",
            "skin": "rtLightWhite80",
            "text": "RichTexthjkg dshjk dsk hjkh dsjkh jkds jkh dskjh kjd jkh dskj kjds kjh jkds hkjh dskj hkjds jk jkdsh jk ",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "rtText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "rtText"), extendConfig({}, controller.args[2], "rtText"));
        flxText.add(rtText);
        flxContent.add(rtTitle, flxText);
        DigitalPillsTeaser.add(flxContent);
        DigitalPillsTeaser.compInstData = {}
        return DigitalPillsTeaser;
    }
})
;
define('com/hcl/demo/ferrari/DigitalPillsTeaser/DigitalPillsTeaserConfig',[],function() {
    return {
        "properties": [{
            "name": "title",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "url",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("com/hcl/demo/ferrari/HamburgerMenu/userHamburgerMenuController", [],function() {
    const MENU_LEFT = -300;
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this.view.preShow = () => {
                if (!this.initDone) {
                    this.onInit();
                    this.initDone = true;
                }
                this.onPreShow();
            };
        },
        onInit() {
            this.view.flxBackground.onClick = () => this.toggle(false);
            this.view.lblClose.onTouchEnd = () => {
                this.toggle(false);
            };
            this.view.segMenu.onRowClick = () => {
                this.toggle(false, true);
                this.onItemSelected(this.view.segMenu.selectedRowItems[0].key);
            };
        },
        onPreShow() {},
        initGettersSetters() {},
        toggle(open, skipAnimation) {
            if (skipAnimation) {
                this.view.isVisible = open;
                this.view.flxBackground.isVisible = open;
                this.view.flxMenu.left = open ? 0 : MENU_LEFT;
            } else {
                const self = this;
                open && (self.view.isVisible = true);
                this.view.flxMenu.animate(voltmx.ui.createAnimation({
                    "0": {
                        left: open ? MENU_LEFT : 0
                    },
                    "100": {
                        left: open ? 0 : MENU_LEFT
                    }
                }), {
                    "duration": 0.5,
                    "iterationCount": 1,
                    "delay": 0,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS
                }, {
                    animationStart: function() {
                        open && (self.view.flxBackground.isVisible = true);
                    },
                    animationEnd: function() {
                        open || (self.view.isVisible = false);
                        open || (self.view.flxBackground.isVisible = false);
                    }
                });
            }
        },
        onItemSelected(key) {
            voltmx.print(`Selected menu item ${key}`);
        }
    };
});
define("com/hcl/demo/ferrari/HamburgerMenu/HamburgerMenuControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/ferrari/HamburgerMenu/HamburgerMenuController", ["com/hcl/demo/ferrari/HamburgerMenu/userHamburgerMenuController", "com/hcl/demo/ferrari/HamburgerMenu/HamburgerMenuControllerActions"], function() {
    var controller = require("com/hcl/demo/ferrari/HamburgerMenu/userHamburgerMenuController");
    var actions = require("com/hcl/demo/ferrari/HamburgerMenu/HamburgerMenuControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/ferrari/HamburgerMenu/HamburgerMenu',[],function() {
    return function(controller) {
        var HamburgerMenu = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "HamburgerMenu",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "HamburgerMenu"), extendConfig({}, controller.args[1], "HamburgerMenu"), extendConfig({}, controller.args[2], "HamburgerMenu"));
        HamburgerMenu.setDefaultUnit(voltmx.flex.DP);
        var flxBackground = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxBackground",
            "isVisible": false,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopysknFlxBackground",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxBackground"), extendConfig({}, controller.args[1], "flxBackground"), extendConfig({}, controller.args[2], "flxBackground"));
        flxBackground.setDefaultUnit(voltmx.flex.DP);
        flxBackground.add();
        var flxMenu = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxMenu",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxOrange",
            "top": "0dp",
            "width": "300dp",
            "zIndex": 1
        }, controller.args[0], "flxMenu"), extendConfig({}, controller.args[1], "flxMenu"), extendConfig({}, controller.args[2], "flxMenu"));
        flxMenu.setDefaultUnit(voltmx.flex.DP);
        var flxHeader = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "80dp",
            "id": "flxHeader",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "7dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxHeader"), extendConfig({}, controller.args[1], "flxHeader"), extendConfig({}, controller.args[2], "flxHeader"));
        flxHeader.setDefaultUnit(voltmx.flex.DP);
        var lblClose = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "80dp",
            "id": "lblClose",
            "isVisible": true,
            "right": 0,
            "skin": "sknLblIconWhite160",
            "text": "s",
            "textStyle": {},
            "top": "0dp",
            "width": "70dp",
            "zIndex": 1
        }, controller.args[0], "lblClose"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblClose"), extendConfig({}, controller.args[2], "lblClose"));
        flxHeader.add(lblClose);
        var flxLogo = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "10%",
            "id": "flxLogo",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "85%"
        }, controller.args[0], "flxLogo"), extendConfig({}, controller.args[1], "flxLogo"), extendConfig({}, controller.args[2], "flxLogo"));
        flxLogo.setDefaultUnit(voltmx.flex.DP);
        var imgLogo = new voltmx.ui.Image2(extendConfig({
            "centerX": "50%",
            "height": "100%",
            "id": "imgLogo",
            "isVisible": true,
            "left": 0,
            "skin": "slImage",
            "src": "horsewhite.png",
            "top": "0dp",
            "width": "85%",
            "zIndex": 1
        }, controller.args[0], "imgLogo"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgLogo"), extendConfig({}, controller.args[2], "imgLogo"));
        flxLogo.add(imgLogo);
        var segMenu = new voltmx.ui.SegmentedUI2(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "data": [{
                "item": "Carts",
                "key": "carts"
            }, {
                "item": "Articles",
                "key": "articles"
            }, {
                "item": "User Profile",
                "key": "profile"
            }, {
                "item": "Logout",
                "key": "logout"
            }],
            "groupCells": false,
            "height": "75%",
            "id": "segMenu",
            "isVisible": true,
            "left": "0dp",
            "needPageIndicator": true,
            "pageOffDotImage": "pageoffdot.png",
            "pageOnDotImage": "pageondot.png",
            "retainSelection": false,
            "rowFocusSkin": "seg2Focus",
            "rowSkin": "sknMenuRed",
            "rowTemplate": "flxMenuItem",
            "sectionHeaderSkin": "sliPhoneSegmentHeader",
            "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
            "separatorColor": "aaaaaa00",
            "separatorRequired": false,
            "separatorThickness": 1,
            "showScrollbars": false,
            "top": "3%",
            "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
            "widgetDataMap": {
                "flxMenuItem": "flxMenuItem",
                "item": "item",
                "key": "key"
            },
            "width": "85%",
            "zIndex": 1
        }, controller.args[0], "segMenu"), extendConfig({
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "segMenu"), extendConfig({}, controller.args[2], "segMenu"));
        flxMenu.add(flxHeader, flxLogo, segMenu);
        HamburgerMenu.add(flxBackground, flxMenu);
        HamburgerMenu.compInstData = {}
        return HamburgerMenu;
    }
})
;
define('com/hcl/demo/ferrari/HamburgerMenu/HamburgerMenuConfig',[],function() {
    return {
        "properties": [],
        "apis": ["toggle"],
        "events": ["onItemSelected"]
    }
});

define("com/hcl/demo/ferrari/NumbersTeaser/userNumbersTeaserController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
            defineGetter(this, 'url', () => {
                return this._url;
            });
            defineSetter(this, 'url', value => {
                this._url = value;
            });
        }
    };
});
define("com/hcl/demo/ferrari/NumbersTeaser/NumbersTeaserControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/hcl/demo/ferrari/NumbersTeaser/NumbersTeaserController", ["com/hcl/demo/ferrari/NumbersTeaser/userNumbersTeaserController", "com/hcl/demo/ferrari/NumbersTeaser/NumbersTeaserControllerActions"], function() {
    var controller = require("com/hcl/demo/ferrari/NumbersTeaser/userNumbersTeaserController");
    var actions = require("com/hcl/demo/ferrari/NumbersTeaser/NumbersTeaserControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "title", function(val) {
            this.view.lblTitle.text = val;
        });
        defineGetter(this, "title", function() {
            return this.view.lblTitle.text;
        });
        defineSetter(this, "text", function(val) {
            this.view.lblText.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.lblText.text;
        });
        defineSetter(this, "showButton", function(val) {
            this.view.flxReadMore.isVisible = val;
        });
        defineGetter(this, "showButton", function() {
            return this.view.flxReadMore.isVisible;
        });
        defineSetter(this, "textBottom", function(val) {
            this.view.flxText.bottom = val;
        });
        defineGetter(this, "textBottom", function() {
            return this.view.flxText.bottom;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_onClickButton_a2f09bf26c51459ebdf88f80c6762bfb = function() {
        if (this.onClickButton) {
            this.onClickButton.apply(this, arguments);
        }
    }
    return controller;
});

define('com/hcl/demo/ferrari/NumbersTeaser/NumbersTeaser',[],function() {
    return function(controller) {
        var NumbersTeaser = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "240dp",
            "id": "NumbersTeaser",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "20dp",
            "isModalContainer": false,
            "skin": "sknFlxGrey",
            "top": "0dp",
            "width": "323dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "NumbersTeaser"), extendConfig({}, controller.args[1], "NumbersTeaser"), extendConfig({}, controller.args[2], "NumbersTeaser"));
        NumbersTeaser.setDefaultUnit(voltmx.flex.DP);
        var flxContent = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "bottom": 20,
            "clipBounds": true,
            "id": "flxContent",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "20dp",
            "isModalContainer": false,
            "right": 20,
            "skin": "slFbox",
            "top": "20dp"
        }, controller.args[0], "flxContent"), extendConfig({}, controller.args[1], "flxContent"), extendConfig({}, controller.args[2], "flxContent"));
        flxContent.setDefaultUnit(voltmx.flex.DP);
        var lblTitle = new voltmx.ui.Label(extendConfig({
            "height": "35dp",
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblRegularRed180",
            "text": "Label",
            "textStyle": {},
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        var flxText = new voltmx.ui.FlexScrollContainer(extendConfig({
            "allowHorizontalBounce": false,
            "allowVerticalBounce": true,
            "bottom": "70dp",
            "bounces": false,
            "clipBounds": true,
            "enableScrolling": true,
            "horizontalScrollIndicator": true,
            "id": "flxText",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "pagingEnabled": false,
            "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
            "skin": "slFSbox",
            "top": "40dp",
            "verticalScrollIndicator": false,
            "width": "100%"
        }, controller.args[0], "flxText"), extendConfig({}, controller.args[1], "flxText"), extendConfig({}, controller.args[2], "flxText"));
        flxText.setDefaultUnit(voltmx.flex.DP);
        var lblText = new voltmx.ui.Label(extendConfig({
            "id": "lblText",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLightWhite80",
            "text": "This is some sample text spanning opn several lines to test the component",
            "textStyle": {},
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblText"), extendConfig({}, controller.args[2], "lblText"));
        flxText.add(lblText);
        var flxReadMore = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "bottom": 0,
            "centerX": "50%",
            "clipBounds": true,
            "height": "60dp",
            "id": "flxReadMore",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_onClickButton_a2f09bf26c51459ebdf88f80c6762bfb,
            "skin": "flxRed",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxReadMore"), extendConfig({}, controller.args[1], "flxReadMore"), extendConfig({}, controller.args[2], "flxReadMore"));
        flxReadMore.setDefaultUnit(voltmx.flex.DP);
        var lblReadMore = new voltmx.ui.Label(extendConfig({
            "centerX": "50%",
            "height": "100%",
            "id": "lblReadMore",
            "isVisible": true,
            "skin": "sknRegularWhite100",
            "text": "Read More",
            "textStyle": {},
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblReadMore"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblReadMore"), extendConfig({}, controller.args[2], "lblReadMore"));
        flxReadMore.add(lblReadMore);
        flxContent.add(lblTitle, flxText, flxReadMore);
        NumbersTeaser.add(flxContent);
        NumbersTeaser.compInstData = {}
        return NumbersTeaser;
    }
})
;
define('com/hcl/demo/ferrari/NumbersTeaser/NumbersTeaserConfig',[],function() {
    return {
        "properties": [{
            "name": "title",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "showButton",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "textBottom",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "url",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onClickButton"]
    }
});

define("com/hcl/demo/ferrari/SimpleHeader/userSimpleHeaderController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/hcl/demo/ferrari/SimpleHeader/SimpleHeaderControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/hcl/demo/ferrari/SimpleHeader/SimpleHeaderController", ["com/hcl/demo/ferrari/SimpleHeader/userSimpleHeaderController", "com/hcl/demo/ferrari/SimpleHeader/SimpleHeaderControllerActions"], function() {
    var controller = require("com/hcl/demo/ferrari/SimpleHeader/userSimpleHeaderController");
    var actions = require("com/hcl/demo/ferrari/SimpleHeader/SimpleHeaderControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "iconLeft", function(val) {
            this.view.lblIconLeft.text = val;
        });
        defineGetter(this, "iconLeft", function() {
            return this.view.lblIconLeft.text;
        });
        defineSetter(this, "iconRight", function(val) {
            this.view.lblRight.text = val;
        });
        defineGetter(this, "iconRight", function() {
            return this.view.lblRight.text;
        });
        defineSetter(this, "title", function(val) {
            this.view.lblTitle.text = val;
        });
        defineGetter(this, "title", function() {
            return this.view.lblTitle.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_onClickLeft_i357e0a8a44e49cfb16f2bf9576e747b = function() {
        if (this.onClickLeft) {
            this.onClickLeft.apply(this, arguments);
        }
    }
    controller.AS_onClickRight_j74f49fdbf3d40c790fdb492c71a6275 = function() {
        if (this.onClickRight) {
            this.onClickRight.apply(this, arguments);
        }
    }
    return controller;
});

define('com/hcl/demo/ferrari/SimpleHeader/SimpleHeader',[],function() {
    return function(controller) {
        var SimpleHeader = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "70dp",
            "id": "SimpleHeader",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "SimpleHeader"), extendConfig({}, controller.args[1], "SimpleHeader"), extendConfig({}, controller.args[2], "SimpleHeader"));
        SimpleHeader.setDefaultUnit(voltmx.flex.DP);
        var lblIconLeft = new voltmx.ui.Label(extendConfig({
            "height": "70dp",
            "id": "lblIconLeft",
            "isVisible": true,
            "left": "0dp",
            "onTouchEnd": controller.AS_onClickLeft_i357e0a8a44e49cfb16f2bf9576e747b,
            "skin": "sknLblIconRed160",
            "text": "5",
            "textStyle": {},
            "top": "0dp",
            "width": "70dp",
            "zIndex": 1
        }, controller.args[0], "lblIconLeft"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblIconLeft"), extendConfig({}, controller.args[2], "lblIconLeft"));
        var lblTitle = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblTitle",
            "isVisible": true,
            "left": "70dp",
            "right": 70,
            "skin": "sknLblRegularRed120",
            "text": "FGT Newsletters",
            "textStyle": {},
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        var lblRight = new voltmx.ui.Label(extendConfig({
            "height": "70dp",
            "id": "lblRight",
            "isVisible": true,
            "onTouchEnd": controller.AS_onClickRight_j74f49fdbf3d40c790fdb492c71a6275,
            "right": 0,
            "skin": "sknLblIconRed160",
            "text": "j",
            "textStyle": {},
            "top": "0dp",
            "width": "70dp",
            "zIndex": 1
        }, controller.args[0], "lblRight"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblRight"), extendConfig({}, controller.args[2], "lblRight"));
        SimpleHeader.add(lblIconLeft, lblTitle, lblRight);
        SimpleHeader.compInstData = {}
        return SimpleHeader;
    }
})
;
define('com/hcl/demo/ferrari/SimpleHeader/SimpleHeaderConfig',[],function() {
    return {
        "properties": [{
            "name": "iconLeft",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "iconRight",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "title",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onClickLeft", "onClickRight"]
    }
});

define("com/hcl/demo/ferrari/SmallTeaser/userSmallTeaserController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
            defineGetter(this, 'newsletterId', () => {
                return this._newsletterId;
            });
            defineSetter(this, 'newsletterId', value => {
                this._newsletterId = value;
            });
        }
    };
});
define("com/hcl/demo/ferrari/SmallTeaser/SmallTeaserControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/hcl/demo/ferrari/SmallTeaser/SmallTeaserController", ["com/hcl/demo/ferrari/SmallTeaser/userSmallTeaserController", "com/hcl/demo/ferrari/SmallTeaser/SmallTeaserControllerActions"], function() {
    var controller = require("com/hcl/demo/ferrari/SmallTeaser/userSmallTeaserController");
    var actions = require("com/hcl/demo/ferrari/SmallTeaser/SmallTeaserControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "newsletterImage", function(val) {
            this.view.imgNewsletter.src = val;
        });
        defineGetter(this, "newsletterImage", function() {
            return this.view.imgNewsletter.src;
        });
        defineSetter(this, "newsletterDate", function(val) {
            this.view.lblDate.text = val;
        });
        defineGetter(this, "newsletterDate", function() {
            return this.view.lblDate.text;
        });
        defineSetter(this, "newsletterNumber", function(val) {
            this.view.lblNumber.text = val;
        });
        defineGetter(this, "newsletterNumber", function() {
            return this.view.lblNumber.text;
        });
        defineSetter(this, "newsletterText", function(val) {
            this.view.lblText.text = val;
        });
        defineGetter(this, "newsletterText", function() {
            return this.view.lblText.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_onClickTeaser_i9ba1f0ce7264c2da660ae311d65a5fb = function() {
        if (this.onClickTeaser) {
            this.onClickTeaser.apply(this, arguments);
        }
    }
    return controller;
});

define('com/hcl/demo/ferrari/SmallTeaser/SmallTeaser',[],function() {
    return function(controller) {
        var SmallTeaser = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "120dp",
            "id": "SmallTeaser",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxGrey",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "SmallTeaser"), extendConfig({}, controller.args[1], "SmallTeaser"), extendConfig({}, controller.args[2], "SmallTeaser"));
        SmallTeaser.setDefaultUnit(voltmx.flex.DP);
        var flxGroup = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxGroup",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_onClickTeaser_i9ba1f0ce7264c2da660ae311d65a5fb,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "flxGroup"), extendConfig({}, controller.args[1], "flxGroup"), extendConfig({}, controller.args[2], "flxGroup"));
        flxGroup.setDefaultUnit(voltmx.flex.DP);
        var flxImage = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "120dp",
            "id": "flxImage",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "120dp",
            "zIndex": 1
        }, controller.args[0], "flxImage"), extendConfig({}, controller.args[1], "flxImage"), extendConfig({}, controller.args[2], "flxImage"));
        flxImage.setDefaultUnit(voltmx.flex.DP);
        var imgNewsletter = new voltmx.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "106dp",
            "id": "imgNewsletter",
            "isVisible": true,
            "skin": "slImage",
            "src": "imageteaser1.png",
            "width": "106dp",
            "zIndex": 1
        }, controller.args[0], "imgNewsletter"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgNewsletter"), extendConfig({}, controller.args[2], "imgNewsletter"));
        flxImage.add(imgNewsletter);
        var flxContent = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "106dp",
            "id": "flxContent",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "130dp",
            "isModalContainer": false,
            "right": "10dp",
            "skin": "slFbox",
            "top": "0dp",
            "zIndex": 1
        }, controller.args[0], "flxContent"), extendConfig({}, controller.args[1], "flxContent"), extendConfig({}, controller.args[2], "flxContent"));
        flxContent.setDefaultUnit(voltmx.flex.DP);
        var lblDate = new voltmx.ui.Label(extendConfig({
            "height": "20dp",
            "id": "lblDate",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLightWhite80",
            "text": "2023.01.01",
            "textStyle": {},
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblDate"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDate"), extendConfig({}, controller.args[2], "lblDate"));
        var lblNumber = new voltmx.ui.Label(extendConfig({
            "height": "25dp",
            "id": "lblNumber",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknMediumWhite140",
            "text": "Nr. 19",
            "textStyle": {},
            "top": "3dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblNumber"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblNumber"), extendConfig({}, controller.args[2], "lblNumber"));
        var lblText = new voltmx.ui.Label(extendConfig({
            "height": "60dp",
            "id": "lblText",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLightWhite80",
            "text": "This is the sample newsletter text which may span up to three lines",
            "textStyle": {},
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblText"), extendConfig({}, controller.args[2], "lblText"));
        flxContent.add(lblDate, lblNumber, lblText);
        flxGroup.add(flxImage, flxContent);
        SmallTeaser.add(flxGroup);
        SmallTeaser.compInstData = {}
        return SmallTeaser;
    }
})
;
define('com/hcl/demo/ferrari/SmallTeaser/SmallTeaserConfig',[],function() {
    return {
        "properties": [{
            "name": "newsletterImage",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "newsletterDate",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "newsletterNumber",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "newsletterText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "newsletterId",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onClickTeaser"]
    }
});

define("flxSampleRowTemplate", [],function() {
    return function(controller) {
        var flxSampleRowTemplate = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "75dp",
            "id": "flxSampleRowTemplate",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleRowTemplate",
            "width": "100%"
        }, {}, {});
        flxSampleRowTemplate.setDefaultUnit(voltmx.flex.DP);
        var lblHeading = new voltmx.ui.Label({
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknLblRowHeading",
            "text": "Heading",
            "textStyle": {},
            "top": "8.00%",
            "width": "45%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblDescription = new voltmx.ui.Label({
            "bottom": "10%",
            "id": "lblDescription",
            "isVisible": true,
            "left": "4%",
            "maxNumberOfLines": 3,
            "maxWidth": "70%",
            "skin": "sknLblDescription",
            "text": "Sub-Heading",
            "textStyle": {},
            "textTruncatePosition": constants.TEXT_TRUNCATE_NONE,
            "top": "42%",
            "width": "70%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblTime = new voltmx.ui.Label({
            "id": "lblTime",
            "isVisible": true,
            "right": "9%",
            "skin": "sknLblTimeStamp",
            "text": "Timestamp",
            "textStyle": {},
            "top": "10%",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblStrip = new voltmx.ui.Label({
            "height": "100%",
            "id": "lblStrip",
            "isVisible": true,
            "left": "0dp",
            "maxWidth": "1%",
            "skin": "sknLblStrip",
            "textStyle": {},
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxSampleRowTemplate.add(lblHeading, lblDescription, lblTime, lblStrip);
        return flxSampleRowTemplate;
    }
})
;
define("flxSectionHeaderTemplate", [],function() {
    return function(controller) {
        var flxSectionHeaderTemplate = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "45dp",
            "id": "flxSectionHeaderTemplate",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleSectionHeaderTemplate",
            "width": "100%"
        }, {}, {});
        flxSectionHeaderTemplate.setDefaultUnit(voltmx.flex.DP);
        var lblHeading = new voltmx.ui.Label({
            "centerY": "50%",
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknSectionHeaderLabelSkin",
            "text": "Heading",
            "textStyle": {},
            "width": "75%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxSectionHeaderTemplate.add(lblHeading);
        return flxSectionHeaderTemplate;
    }
})
;
define("flxMenuItem", [],function() {
    return function(controller) {
        var flxMenuItem = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "60dp",
            "id": "flxMenuItem",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "breakpoints": [640, 1024, 1366]
        }, {}, {});
        flxMenuItem.setDefaultUnit(voltmx.flex.DP);
        var key = new voltmx.ui.Label({
            "id": "key",
            "isVisible": false,
            "left": "148dp",
            "skin": "defLabel",
            "textStyle": {},
            "top": "20dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var item = new voltmx.ui.Label({
            "height": "100%",
            "id": "item",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblRegularDarkGrey100",
            "text": "Label",
            "textStyle": {},
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxMenuItem.add(key, item);
        return flxMenuItem;
    }
})
;
define("userflxSampleRowTemplateController", {
    //Type your controller code here 
});
define("flxSampleRowTemplateControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSampleRowTemplateController", ["userflxSampleRowTemplateController", "flxSampleRowTemplateControllerActions"], function() {
    var controller = require("userflxSampleRowTemplateController");
    var controllerActions = ["flxSampleRowTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSectionHeaderTemplateController", {
    //Type your controller code here 
});
define("flxSectionHeaderTemplateControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSectionHeaderTemplateController", ["userflxSectionHeaderTemplateController", "flxSectionHeaderTemplateControllerActions"], function() {
    var controller = require("userflxSectionHeaderTemplateController");
    var controllerActions = ["flxSectionHeaderTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxMenuItemController", {
    //Type your controller code here 
});
define("flxMenuItemControllerActions", {
    //Type your controller code here 
});
define("flxMenuItemController", ["userflxMenuItemController", "flxMenuItemControllerActions"], function() {
    var controller = require("userflxMenuItemController");
    var controllerActions = ["flxMenuItemControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

require(['applicationController','com/hcl/demo/ferrari/BigTeaser/BigTeaserController','com/hcl/demo/ferrari/BigTeaser/BigTeaser','com/hcl/demo/ferrari/BigTeaser/BigTeaserConfig','com/hcl/demo/ferrari/DigitalPillsTeaser/DigitalPillsTeaserController','com/hcl/demo/ferrari/DigitalPillsTeaser/DigitalPillsTeaser','com/hcl/demo/ferrari/DigitalPillsTeaser/DigitalPillsTeaserConfig','com/hcl/demo/ferrari/HamburgerMenu/HamburgerMenuController','com/hcl/demo/ferrari/HamburgerMenu/HamburgerMenu','com/hcl/demo/ferrari/HamburgerMenu/HamburgerMenuConfig','com/hcl/demo/ferrari/NumbersTeaser/NumbersTeaserController','com/hcl/demo/ferrari/NumbersTeaser/NumbersTeaser','com/hcl/demo/ferrari/NumbersTeaser/NumbersTeaserConfig','com/hcl/demo/ferrari/SimpleHeader/SimpleHeaderController','com/hcl/demo/ferrari/SimpleHeader/SimpleHeader','com/hcl/demo/ferrari/SimpleHeader/SimpleHeaderConfig','com/hcl/demo/ferrari/SmallTeaser/SmallTeaserController','com/hcl/demo/ferrari/SmallTeaser/SmallTeaser','com/hcl/demo/ferrari/SmallTeaser/SmallTeaserConfig','flxSampleRowTemplate','flxSectionHeaderTemplate','flxMenuItem','flxSampleRowTemplateController','flxSectionHeaderTemplateController','flxMenuItemController'], function(){});

define("sparequirefileslist", function(){});

