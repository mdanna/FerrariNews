define("frmNewsletter", function() {
    return function(controller) {
        function addWidgetsfrmNewsletter() {
            this.setDefaultUnit(voltmx.flex.DP);
            var headerNewsletter = new com.hcl.demo.ferrari.SimpleHeader({
                "height": "70dp",
                "id": "headerNewsletter",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "lblIconLeft": {
                        "text": "n"
                    },
                    "lblRight": {
                        "text": "  "
                    },
                    "lblTitle": {
                        "text": "Nr. 19"
                    },
                    "SimpleHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxScrollerVertical = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": false,
                "bottom": 0,
                "bounces": false,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxScrollerVertical",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "70dp",
                "verticalScrollIndicator": false,
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxScrollerVertical.setDefaultUnit(voltmx.flex.DP);
            var flxContainerAutomotive = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "500dp",
                "id": "flxContainerAutomotive",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxContainerAutomotive.setDefaultUnit(voltmx.flex.DP);
            var lblTitleAutomotive = new voltmx.ui.Label({
                "height": "60dp",
                "id": "lblTitleAutomotive",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblRegularRed140",
                "text": "AUTOMOTIVE",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxScrollerHorizontalAutomotive = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": false,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "440dp",
                "horizontalScrollIndicator": false,
                "id": "flxScrollerHorizontalAutomotive",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_HORIZONTAL,
                "skin": "slFSbox",
                "top": "60dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxScrollerHorizontalAutomotive.setDefaultUnit(voltmx.flex.DP);
            var TeaserBig = new com.hcl.demo.ferrari.BigTeaser({
                "height": "440dp",
                "id": "TeaserBig",
                "isVisible": true,
                "left": "20dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "323dp",
                "zIndex": 1,
                "overrides": {
                    "BigTeaser": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            TeaserBig.url = "";
            var CopyTeaserBig0j26379a74b534f = new com.hcl.demo.ferrari.BigTeaser({
                "height": "440dp",
                "id": "CopyTeaserBig0j26379a74b534f",
                "isVisible": true,
                "left": "20dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "323dp",
                "zIndex": 1,
                "overrides": {
                    "BigTeaser": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyTeaserBig0j26379a74b534f.url = "";
            flxScrollerHorizontalAutomotive.add(TeaserBig, CopyTeaserBig0j26379a74b534f);
            flxContainerAutomotive.add(lblTitleAutomotive, flxScrollerHorizontalAutomotive);
            var flxContainerCross = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "500dp",
                "id": "flxContainerCross",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxContainerCross.setDefaultUnit(voltmx.flex.DP);
            var lblTitleCross = new voltmx.ui.Label({
                "height": "60dp",
                "id": "lblTitleCross",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblRegularGreen140",
                "text": "CROSS",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxScrollerHorizontalCross = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": 0,
                "bounces": false,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": false,
                "id": "flxScrollerHorizontalCross",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_HORIZONTAL,
                "skin": "slFSbox",
                "top": "60dp",
                "verticalScrollIndicator": false,
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxScrollerHorizontalCross.setDefaultUnit(voltmx.flex.DP);
            flxScrollerHorizontalCross.add();
            flxContainerCross.add(lblTitleCross, flxScrollerHorizontalCross);
            var flxContainerStartup = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "500dp",
                "id": "flxContainerStartup",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxContainerStartup.setDefaultUnit(voltmx.flex.DP);
            var lblTitleStartup = new voltmx.ui.Label({
                "height": "60dp",
                "id": "lblTitleStartup",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblRegularYellow140",
                "text": "STARTUP",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxScrollerHorizontalStartup = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": 0,
                "bounces": false,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": false,
                "id": "flxScrollerHorizontalStartup",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_HORIZONTAL,
                "skin": "slFSbox",
                "top": "60dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxScrollerHorizontalStartup.setDefaultUnit(voltmx.flex.DP);
            flxScrollerHorizontalStartup.add();
            flxContainerStartup.add(lblTitleStartup, flxScrollerHorizontalStartup);
            var flxContainerNumbers = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": true,
                "height": "300dp",
                "id": "flxContainerNumbers",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxContainerNumbers.setDefaultUnit(voltmx.flex.DP);
            var lblTitleNumbers = new voltmx.ui.Label({
                "height": "60dp",
                "id": "lblTitleNumbers",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblRegularWhite140",
                "text": "BY THE NUMBERS",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxScrollerHorizontalNumbers = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": 0,
                "bounces": false,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "240dp",
                "horizontalScrollIndicator": false,
                "id": "flxScrollerHorizontalNumbers",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_HORIZONTAL,
                "skin": "slFSbox",
                "top": "60dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxScrollerHorizontalNumbers.setDefaultUnit(voltmx.flex.DP);
            var NumbersTeaser = new com.hcl.demo.ferrari.NumbersTeaser({
                "height": "240dp",
                "id": "NumbersTeaser",
                "isVisible": true,
                "left": "20dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "323dp",
                "zIndex": 1,
                "overrides": {
                    "NumbersTeaser": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            NumbersTeaser.url = "";
            flxScrollerHorizontalNumbers.add(NumbersTeaser);
            flxContainerNumbers.add(lblTitleNumbers, flxScrollerHorizontalNumbers);
            var flxContainerDigitalPills = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": true,
                "height": "500dp",
                "id": "flxContainerDigitalPills",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxContainerDigitalPills.setDefaultUnit(voltmx.flex.DP);
            var lblTitleDigitalPills = new voltmx.ui.Label({
                "height": "60dp",
                "id": "lblTitleDigitalPills",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblRegularWhite140",
                "text": "DIGITAL PILLS",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxScrollerHorizontalDigitalPills = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": 0,
                "bounces": false,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "440dp",
                "horizontalScrollIndicator": false,
                "id": "flxScrollerHorizontalDigitalPills",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_HORIZONTAL,
                "skin": "slFSbox",
                "top": "60dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxScrollerHorizontalDigitalPills.setDefaultUnit(voltmx.flex.DP);
            var DigitalPillsTeaser = new com.hcl.demo.ferrari.DigitalPillsTeaser({
                "height": "440dp",
                "id": "DigitalPillsTeaser",
                "isVisible": true,
                "left": "20dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxGrey",
                "top": "0dp",
                "width": "323dp",
                "zIndex": 1,
                "overrides": {
                    "DigitalPillsTeaser": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            DigitalPillsTeaser.url = "";
            flxScrollerHorizontalDigitalPills.add(DigitalPillsTeaser);
            flxContainerDigitalPills.add(lblTitleDigitalPills, flxScrollerHorizontalDigitalPills);
            flxScrollerVertical.add(flxContainerAutomotive, flxContainerCross, flxContainerStartup, flxContainerNumbers, flxContainerDigitalPills);
            this.compInstData = {
                "headerNewsletter": {
                    "iconLeft": "n",
                    "iconRight": "  ",
                    "title": "Nr. 19",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "TeaserBig": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "CopyTeaserBig0j26379a74b534f": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "NumbersTeaser": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "DigitalPillsTeaser": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(headerNewsletter, flxScrollerVertical);
        };
        return [{
            "addWidgets": addWidgetsfrmNewsletter,
            "enabledForIdleTimeout": false,
            "id": "frmNewsletter",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmDarkGrey",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});