define("userfrmLoginController", {
    onViewCreated() {
        this.view.init = () => {
            this.view.flxLoginButton.onClick = () => {
                VMXFoundry.getIntegrationService('FerrariNewsletter').invokeOperation('getNewsletter', {}, {}, (response) => {
                    data.newslettercatalogue = response.newslettercatalogue;
                    new voltmx.mvc.Navigation('frmMain').navigate();
                }, (error) => alert('Error retrieving newsletter data'));
            };
        };
    }
});
define("frmLoginControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("frmLoginController", ["userfrmLoginController", "frmLoginControllerActions"], function() {
    var controller = require("userfrmLoginController");
    var controllerActions = ["frmLoginControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
