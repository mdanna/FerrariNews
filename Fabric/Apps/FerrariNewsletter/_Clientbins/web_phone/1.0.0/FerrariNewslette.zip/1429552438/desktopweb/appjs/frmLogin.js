define("frmLogin", function() {
    return function(controller) {
        function addWidgetsfrmLogin() {
            this.setDefaultUnit(voltmx.flex.DP);
            var imgBackground = new voltmx.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgBackground",
                "isVisible": true,
                "skin": "slImage",
                "src": "image4.jpg",
                "width": "200%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLogin = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "70%",
                "id": "flxLogin",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxLogin",
                "width": "90%",
                "zIndex": 1
            }, {}, {});
            flxLogin.setDefaultUnit(voltmx.flex.DP);
            var imgHorse = new voltmx.ui.Image2({
                "centerX": "50%",
                "height": "25%",
                "id": "imgHorse",
                "isVisible": true,
                "left": "147dp",
                "skin": "slImage",
                "src": "horsewhite.png",
                "top": "5%",
                "width": "25%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTitle = new voltmx.ui.Label({
                "centerX": "50%",
                "height": "5%",
                "id": "lblTitle",
                "isVisible": true,
                "skin": "sknRegularWhite100",
                "text": "FGT INNOVATION",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContent = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "65%",
                "id": "flxContent",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "135dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1
            }, {}, {});
            flxContent.setDefaultUnit(voltmx.flex.DP);
            var flxEmail = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "18%",
                "id": "flxEmail",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxEmail.setDefaultUnit(voltmx.flex.DP);
            var lblEmailAddress = new voltmx.ui.Label({
                "height": "35%",
                "id": "lblEmailAddress",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknRegularWhite60",
                "text": "Email Address",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEmailAddressField = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "65%",
                "id": "flxEmailAddressField",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTransparentBorderWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxEmailAddressField.setDefaultUnit(voltmx.flex.DP);
            var lblEmailAddressField = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblEmailAddressField",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknRegularWhite80",
                "text": "charles.leclerc@ferrari.it",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {});
            flxEmailAddressField.add(lblEmailAddressField);
            flxEmail.add(lblEmailAddress, flxEmailAddressField);
            var flxPassword = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "18%",
                "id": "flxPassword",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxPassword.setDefaultUnit(voltmx.flex.DP);
            var lblPassword = new voltmx.ui.Label({
                "height": "35%",
                "id": "lblPassword",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknRegularWhite60",
                "text": "Password",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPasswordField = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "65%",
                "id": "flxPasswordField",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTransparentBorderWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxPasswordField.setDefaultUnit(voltmx.flex.DP);
            var lblPasswordField = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblPasswordField",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknRegularWhite80",
                "text": "**********",
                "textStyle": {},
                "top": "6%",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {});
            flxPasswordField.add(lblPasswordField);
            flxPassword.add(lblPassword, flxPasswordField);
            var flxLoginButton = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "15%",
                "id": "flxLoginButton",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "55dp",
                "isModalContainer": false,
                "skin": "flxRed",
                "top": "5%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxLoginButton.setDefaultUnit(voltmx.flex.DP);
            var lblLogin = new voltmx.ui.Label({
                "centerX": "50%",
                "height": "100%",
                "id": "lblLogin",
                "isVisible": true,
                "skin": "sknRegularWhite100",
                "text": "LOG IN",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoginButton.add(lblLogin);
            var flxBiometricsButton = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15%",
                "id": "flxBiometricsButton",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTransparentBorderWhite",
                "top": "5%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxBiometricsButton.setDefaultUnit(voltmx.flex.DP);
            var lblBiometrics = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblBiometrics",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknRegularWhite80",
                "text": "LOG IN WITH BIOMETRICS",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {});
            flxBiometricsButton.add(lblBiometrics);
            flxContent.add(flxEmail, flxPassword, flxLoginButton, flxBiometricsButton);
            flxLogin.add(imgHorse, lblTitle, flxContent);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "flxLogin": {
                        "maxWidth": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "imgBackground": {
                        "height": {
                            "type": "string",
                            "value": "1152dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1440dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogin": {
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "imgBackground": {
                        "height": {
                            "type": "string",
                            "value": "1728dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "2160dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogin": {
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {}
            this.add(imgBackground, flxLogin);
        };
        return [{
            "addWidgets": addWidgetsfrmLogin,
            "enabledForIdleTimeout": false,
            "id": "frmLogin",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmDarkGrey",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});